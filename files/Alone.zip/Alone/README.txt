===========
***ALONE***
===========
All sprites, scripts, sounds, and scenes 
Created by Michael Bosik, Matthew Iandoli, Luke Trujillo
Created using Unity Game Engine

How to Launch (Windows Only):
1. Unzip the .zip folder containing the files
2. Double click on "Alone.exe"
3. Click "Play"

How to Play:
Use the mouse to aim your gun
Click to fire at the Gloups
With each bullet you fire, an impulse of force sends you in the opposite direction.
Don't fly off screen or lose your health!